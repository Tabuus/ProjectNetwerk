import React, { Component } from 'react';

import {
  AppRegistry,
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  ImageBackground
} from 'react-native';

export default class SignupScreen extends React.Component{
    constructor(props){
       super(props);
       this.state ={ 
           
        }
     }

    render(){
        return(
          <ImageBackground style={styles.container} source={require('./../assets/bg.jpg')}>
            <KeyboardAvoidingView style={styles.container} behavior="padding">
                <View style={styles.logoContainer}>
                    <Text style={styles.title}>NETWERK </Text>
                    <View style={styles.Rectangle} />
                </View>

                <View style= {styles.formContainer} >
                     <TextInput
                        placeholder="First and Last Name"
                        style={styles.input}
                        underlineColorAndroid = 'transparent'
                        onChangeText={(displayName) => this.props.navigation.navigate('SignUpCompanyInfo',{displayName:displayName})}
                      />
                      <TextInput
                        placeholder="Photo URL"
                        style={styles.input}
                        underlineColorAndroid = 'transparent'
                        onChangeText={(photo) => this.props.navigation.navigate('SignUpCompanyInfo',{photo:photo})}

                      />
                      <TextInput
                        placeholder="User Name"
                        style={styles.input}
                        underlineColorAndroid = 'transparent'
                        onChangeText={(username) => this.props.navigation.navigate('SignUpCompanyInfo',{username:username})}
                      />
                     <TextInput
                        placeholder="Password"
                        style={styles.input}
                        underlineColorAndroid = 'transparent'
                        onChangeText={(passwerd) => this.props.navigation.navigate('SignUpCompanyInfo',{passwerd:passwerd})}
                     />

                    <TouchableOpacity style={styles.buttonContainer} activeOpacity={0.7} onPress={ () =>
                    this.props.navigation.navigate('Signup2') }>
                        <Text style={styles.buttonText}>NEXT</Text>
                    </TouchableOpacity>

                    <TouchableOpacity activeOpacity={0.7} onPress={() => this.props.navigation.navigate('Login')}>
                        <Text style={styles.smallText}>have an account?</Text>
                    </TouchableOpacity>
                </View>
            </ KeyboardAvoidingView>
            </ImageBackground>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

    logoContainer: {
        flex: 1,
        marginBottom: 0,
    },

    Rectangle: {
        marginTop: 20,
        marginLeft: 63,
        width: 60,
        height: 8,
        backgroundColor: 'white'
    },

    title: {
        marginTop: 100,
        fontSize: 40,
        fontWeight: 'bold',
        textAlign: 'left',
        color: 'white',
        marginLeft: 60,
        letterSpacing: 3
    },

    formContainer: {
        flex: 2,
        paddingVertical: 15,
    },

    input: {
        height: 45,
        backgroundColor: 'white',
        color: 'black',
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 10,
        marginTop: 12,
        marginLeft: 60,
        marginRight: 60,
        letterSpacing: 0.5
    },

    buttonContainer: {
        marginTop: 40,
        marginLeft: 60,
        marginRight:60,
        paddingVertical: 15,
        borderRadius: 10,
        backgroundColor: '#E0224F'
    },

    buttonText: {
        textAlign: 'center',
        color: 'white',
        shadowColor: '#000',
        shadowOffset: {
            width: 0, 
            height: 2
        },
        fontSize: 15,
        fontWeight: 'bold',
        shadowOpacity: 0.8,
        shadowRadius: 5
    },

    smallText: {
        textAlign:'right', 
        color:'white', 
        marginTop:4, 
        marginRight: 64, 
        letterSpacing: 0.5
    },

    error: {
        color: 'red'
    }
});