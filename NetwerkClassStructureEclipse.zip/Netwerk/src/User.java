import java.util.ArrayList;

public class User {
	String username;
	String phone;
	String email;
	String password;
	String profileType;
	Integer id;
	Profile profile;
	ArrayList<Integer> connections;

	//User Constructor
	public User(String first, String last, String email, String username, String password, String profileType, Integer id) {
		//initialize user all user info
		this.username = username;
		this.email = email;
		this.password = password;
		this.id = id;
		this.profileType = profileType;
		this.connections = new ArrayList<Integer>();
		
		//create correct profile based on profile type
		if(profileType.equals("employee")) {
			this.profile = new Employee();
		}else {
			this.profile = new Company();
		}	
	}

	//sets user phone number
	void SetPhone(String input) {
		this.phone =input;
	}
	
	//sets user email
	void SetEmail(String input) {
		this.email = input;
	}
	
	//sets user password
	void SetPassword(String input) {
		this.password = input;
	}
	
	//returns profile id
	Integer GetId() {
		return this.id;
	}
	
	//returns username
	String GetName() {
		return this.username;
	}
	
	//returns users phone
	String GetPhone() {
		return this.phone;
	}
	
	//returns user email
	String GetEmail() {
		return this.email;
	}
	
	//returns user password
	String GetPassword() {
		return this.password;
	}
	
	//returns profile type
	String GetProfileType() {
		return this.profileType;
	}
	
	//Add user to connections list
	void AddConnection(int index) {
		//check that new user is not already a part of connections
		boolean newUser = true;
		for(int i=0;i<this.connections.size();i++) {
			if(this.connections.get(i).intValue() == index) {
				newUser = false;
			}
		}
		
		if(newUser) {
			this.connections.add(index);
		}
	}
	
	//Remove user from connections list
	void RemoveConnection(int index) {
		//delete connection if connection exists
		for(int i=0;i<this.connections.size();i++) {
			if(this.connections.get(i).intValue() == index) {
				this.connections.remove(i);
			}
		}
	}
	
	//get array of user connections
	ArrayList<Integer> GetConnections(){
		return this.connections;
	}
	
	Profile GetProfile() {
		return this.profile;
	}
	
	
	
	
	

}
