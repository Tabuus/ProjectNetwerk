import java.util.ArrayList;

public class Employee extends Profile {
	ArrayList<Job> experience;
	ArrayList<Boolean> privacy;
	
	//Create Employee with no experience and privacy set to private
	Employee(){
		super();
		
		this.experience = new ArrayList<Job>();
		this.privacy = new ArrayList<Boolean>(3);
		for(int i=0;i<3;i++) {
			this.privacy.add(false);
		}
	}

	//add job to experience arraylist
	void AddJob(String company, String position, String duties, String start, String finish) {
		//create new job object
		Job temp = new Job();
		
		//update job info
		temp.SetCompany(company);
		temp.SetPostion(position);
		temp.SetDuties(duties);
		temp.SetStart(start);
		temp.SetFinish(finish);
		
		//add job to experience list
		this.experience.add(temp);
	}
		
	//return list of experiences
	ArrayList<Job> GetJobs( ){
		return this.experience;
	}
		
	//return array with privacy settings
	ArrayList<Boolean> GetPrivacy( ){
		return this.privacy;
	}
		
	//change privacy setting for username display
	void UsernameDisplay() {
		Boolean cur = this.privacy.get(0);
		this.privacy.set(0, !cur);
	}
		
	//change privacy setting for phone display
	void PhoneDisplay() { 
		Boolean cur = this.privacy.get(1);
		this.privacy.set(1, !cur);
	}
		
	//change privacy setting for email display
	void EmailDisplay() { 
		Boolean cur = this.privacy.get(2);
		this.privacy.set(2, !cur);
	}

}
