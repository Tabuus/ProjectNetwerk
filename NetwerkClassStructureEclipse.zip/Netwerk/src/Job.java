
public class Job {
	String company;
	String position;
	String duties;
	String start;
	String finish;
	
	//update company name
	void SetCompany(String update) {
		this.company = update;
	}
	
	//update position
	void SetPostion(String update) {
		this.position = update;
	}
	
	//update duties
	void SetDuties(String update) {
		this.duties = update;
	}
	
	//update start date
	void SetStart(String update) {
		this.start = update;
	}
	
	//update end date
	void SetFinish(String update) {
		this.finish = update;
	}
	
	//return formatted string with company info
	String GetInfo() {
		String format = "Company: "+ this.company + "\nPosition: "+this.position;
		format += "\nDuties: " + this.duties + "\nStart: "+this.start + "\nEnd: " + this.finish;
		return format;
	}
}
