
public class Company extends Profile {
	String location;
	String type;
	
	public Company() {
		super();
	}
	
	//set company location
	void SetLocation(String input) { 
		this.location = input;
	}
		
	//set company type
	void SetCompanyType(String input) { 
		this.type = input;
	}
		
	//get company location
	String GetLocation() {
		return this.location;
	}
		
	//get company type
	String GetCompanyType() {
		return this.type;
	}

}
