import java.util.ArrayList;

public class Network {
	ArrayList<User> users;
	
	//create network with no users
	public Network() {
		users = new ArrayList<User>();
	}
	
	//add users to eachothers connections list
	void Connect(int user1, int user2) {
		//get users from users list
		User first = this.users.get(user1);
		User second = this.users.get(user2);
		
		//add users to eachothers connections
		first.AddConnection(user2);
		second.AddConnection(user1);
	}
	
	//remove users from eachothers connections list
	void Disconnect(int user1, int user2) {
		//get users from users list
		User first = this.users.get(user1);
		User second = this.users.get(user2);
				
		//remove users from eachothers connections
		first.RemoveConnection(user2);
		second.RemoveConnection(user1);
	}
	
	//add user to network
	void AddUser (String first, String last, String email, String username, String password, String profileType) {
		User temp = new User(first,last, email, username, password, profileType, this.users.size());
		this.users.add(temp);
	}

	//return id of users that match search key
	ArrayList<Integer>  Search( String searchKey ){
		ArrayList<Integer> results = new ArrayList<Integer>();
		
		for(int i=0;i<this.users.size();i++) {
			if(this.users.get(i).GetName().startsWith(searchKey)) {
				results.add(users.get(i).GetId());
			}
		}
		
		return results;
	}
	
	//validate sign up information 
	Boolean ValidSignUp(String email, String username) {
		boolean valid = true;
		
		if(email.equals("") || email == null) {
			valid = false;
		}else if(username.equals("") || username == null) {
			valid = false;
		}else {
			for(int i=0;i<this.users.size();i++) {
				if(username.equalsIgnoreCase(this.users.get(i).GetName())) {
					valid = false;
				}else if(email.equalsIgnoreCase(this.users.get(i).GetEmail())) {
					valid = false;
				}
			}
		}
		
		return valid;
	}
	
	//validate login information
	Boolean ValidLogIn(String email, String password) {
		boolean valid = true;
		
		if(email.equals("") || email == null) {
			valid = false;
		}else if(password.equals("") || password == null) {
			valid = false;
		}else {
			valid = false;
			for(int i=0;i<this.users.size();i++) {
				if(email.equalsIgnoreCase(this.users.get(i).GetEmail())) {
					if(password.equals(this.users.get(i).GetPassword())) {
						valid = true;
					}
				}
			}
		}
		
		return valid;
	}

}
