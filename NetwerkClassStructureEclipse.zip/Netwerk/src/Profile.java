import java.util.ArrayList;

public class Profile {
	String displayName;
	String profilePic;
	String description;
	
	//set display name to input
	void SetDisplayName(String input) {
		this.displayName = input;
	}
	
	//set description to input
	void SetDescription(String input) {
		this.description = input;
	}
	
	//set profile picture to input
	void SetPicture(String input) {
		this.profilePic = input;
	}
	
	//return display name
	String GetDisplayName() {
		return this.displayName;
	}
	
	//return description
	String GetDescription() {
		return this.description;
	}
	
	//return picture
	String GetPicture() {
		return this.profilePic;
	}
	
	/*
	 *	The following functions will be implemented by Employee subclass
	 */
	
	//add job to experience arraylist
	void AddJob(String company, String position, String duties, String start, String finish) {
		
	}
	
	//return list of experiences
	ArrayList<Job> GetJobs( ){
		return null;
	}
	
	//return array with privacy settings
	ArrayList<Boolean> GetPrivacy( ){
		return null;
	}
	
	//change privacy setting for username display
	void UsernameDisplay() { }
	
	//change privacy setting for phone display
	void PhoneDisplay() { }
	
	//change privacy setting for email display
	void EmailDisplay() { }
	
	
	/*
	 * The following functions will be implemented by Company subclass
	 */
	
	//set company location
	void SetLocation(String input) { }
	
	//set company type
	void SetCompanyType(String input) { }
	
	//get company location
	String GetLocation() {
		return null;
	}
	
	//get company type
	String GetCompanyType() {
		return null;
	}
	
}
